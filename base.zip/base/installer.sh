#/bin/sh
mkdir /usr/crossepg/scripts/virgin

VIRGIN='/usr/crossepg/scripts/virgin'
PROVIDER='/usr/crossepg/providers'
NUMBER='/usr/lib/enigma2/python/Plugins/SystemPlugins/CrossEPG'

cp -f delete_script.conf /$PROVIDER
cp -f update_script.conf /$PROVIDER
cp -f virgin_script.conf /$PROVIDER
cp -f alias.conf /$VIRGIN
cp -f alias.py /$VIRGIN
cp -f delete.py /$VIRGIN
cp -f update.py /$VIRGIN
cp -f version.py /$NUMBER
cp -f VERSION /$NUMBER
chmod 755 /usr/crossepg/scripts/virgin/alias.conf
chmod 755 /usr/crossepg/scripts/virgin/alias.py
chmod 755 /usr/crossepg/scripts/virgin/update.py
clear
echo ""
echo ""
echo ""
echo ""
echo "        *********************************************************************"
echo "        *                                                                   *"
echo "        *          The required files have now being installed              *"
echo "        *       You will now get an option to choose your ITV region        *"
echo "        *    And will allow you to update the alias file with crossepg      *"
echo "        *                                                                   *"
echo "        *********************************************************************"
sleep 10
exit 0

