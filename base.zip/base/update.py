#!/bin/sh
#Jenseneverest Alias Update file.
printf "Updating virgin alias.conf file.... \n"
wget -q https://github.com/jenseneverest/alias/raw/master/alias.conf -O /usr/crossepg/scripts/virgin/alias.conf
exit 0
