#!/bin/sh
#Jenseneverest Alias Update file.
printf "Updating virgin alias.conf file.... \n"
wget -q https://github.com/jenseneverest/alias/raw/master/alias.conf -O /usr/crossepg/scripts/virgin/alias.conf
sed -i 's/#ITV Tyne Tees HD/ITV Tyne Tees HD/g; s/#ITV +1 Tyne Tees/ITV +1 Tyne Tees/g' /usr/crossepg/scripts/virgin/alias.conf 
sleep 2     
exit 0
