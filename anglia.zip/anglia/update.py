#!/bin/sh
#Jenseneverest Alias Update file.
printf "Updating virgin alias.conf file.... \n"
wget -q https://github.com/jenseneverest/alias/raw/master/alias.conf -O /usr/crossepg/scripts/virgin/alias.conf
sed -i 's/#ITV Anglia HD/ITV Anglia HD/g; s/#ITV +1 Anglia/ITV +1 Anglia/g' /usr/crossepg/scripts/virgin/alias.conf 
sleep 2     
exit 0
