#!/bin/sh
#Jenseneverest Alias Update file.
printf "Updating virgin alias.conf file.... \n"
wget -q --no-check-certificate https://github.com/jenseneverest/alias/raw/master/alias.conf -O /usr/crossepg/scripts/virgin/alias.conf
sed -i 's/#ITV Central West HD/ITV Central West HD/g; s/#ITV +1 Central/ITV +1 Central/g' /usr/crossepg/scripts/virgin/alias.conf
sleep 2
exit 0
