#!/bin/sh
#Jenseneverest Alias Update file.
printf "Updating virgin alias.conf file.... \n"
wget -q https://github.com/jenseneverest/alias/raw/master/alias.conf -O /usr/crossepg/scripts/virgin/alias.conf
sed -i 's/#ITV Yorkshire HD/ITV Yorkshire HD/g; s/#ITV +1 Yorkshire/ITV +1 Yorkshire/g' /usr/crossepg/scripts/virgin/alias.conf 
sleep 2     
exit 0
